#ifndef STUBS_H_
#define STUBS_H_

#include "sds_incl.h"
#include "portinfo.h"
#include "accel_info.h"
#include "sds_lib.h"

extern cf_request_handle_t _p0_request_0;
extern cf_request_handle_t _p0_request_1;

extern size_t _p0_rgb_2_gray_0_num_gray;



#endif
