#ifdef __cplusplus
extern "C" {
#endif

void _p0_cf_register(int);
void _p0_cf_unregister(int);
#ifdef __cplusplus
};
#endif
