-= SD card boot image =-

Platform: zed
Application: C:/training/hls/demos/toolDemo_zed_test/SDSoC_lab_design_complete/SDRelease/_sds/swstubs/SDSoC_lab_design_complete.elf

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
