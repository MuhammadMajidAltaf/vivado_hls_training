#include "lab_design.h"
#include "rgb_2_gray.h"

//Reference https://www.mathworks.com/help/matlab/ref/rgb2gray.html for
//the values
void rgb_2_gray(uint32_t color[2073600], uint8_t gray[2073600]) {

	int i, j;
	int index;
	uint32_t red, green, blue;
	uint32_t thisPixel;

	for (i = 0; i < FRAME_HEIGHT; i++) {
		for (j = 0; j < FRAME_WIDTH; j++) {
#pragma AP PIPELINE II = 1
			index = (i * FRAME_WIDTH + j);

			thisPixel = color[index];
			red = (uint32_t) getRed(thisPixel);
			green = (uint32_t) getGreen(thisPixel);
			blue = (uint32_t) getBlue(thisPixel);

			uint16_t gr = (uint16_t)((red * 298 + green * 587 + blue * 114) >> 10); //Divide by 1024 (should be 1000 but not using floating point)

			gray[index] = (uint8_t) gr;
		}
	}

}

#include <stdio.h>
#include <stdlib.h>
#include "cf_stub.h"
#ifdef __cplusplus
extern "C" {
#endif
void _p0_rgb_2_gray_0(uint32_t color[2073600], uint8_t gray[2073600]);
#ifdef __cplusplus
}
#endif
void _p0_rgb_2_gray_0(uint32_t color[2073600], uint8_t gray[2073600])
{
  switch_to_next_partition(0);
  int start_seq[3];
  start_seq[0] = 0x00000000;
  start_seq[1] = 0x00010000;
  start_seq[2] = 0x00020000;
  cf_request_handle_t _p0_swinst_rgb_2_gray_0_cmd;
  cf_send_i(&(_p0_swinst_rgb_2_gray_0.cmd_rgb_2_gray), start_seq, 3*sizeof(int), &_p0_swinst_rgb_2_gray_0_cmd);
  cf_wait(_p0_swinst_rgb_2_gray_0_cmd);

  cf_send_i(&(_p0_swinst_rgb_2_gray_0.color), color, 8294400, &_p0_request_0);

  cf_receive_i(&(_p0_swinst_rgb_2_gray_0.gray), gray, 2073600, &_p0_rgb_2_gray_0_num_gray, &_p0_request_1);

  cf_wait(_p0_request_0);
  cf_wait(_p0_request_1);
}



