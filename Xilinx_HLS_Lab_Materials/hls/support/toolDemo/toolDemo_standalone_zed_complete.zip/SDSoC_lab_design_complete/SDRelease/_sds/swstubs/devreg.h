#ifndef _SDS_DEVREG_H
#define _SDS_DEVREG_H
/* File: C:/training/hls/demos/toolDemo_zed_test/SDSoC_lab_design_complete/SDRelease/_sds/p0/.cf_work/devreg.h */
#ifdef __cplusplus
extern "C" {
#endif

void _p0_cf_register(int);
void _p0_cf_unregister(int);
#ifdef __cplusplus
};
#endif
#endif /* _SDS_DEVREG_H_ */
