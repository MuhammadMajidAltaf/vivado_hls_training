-= SD card boot image =-

Platform: zc702
Application: C:/training/hls/demos/toolDemo/SDSoC_lab_design_complete/SDDebug/_sds/swstubs/SDSoC_lab_design_complete.elf

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
   Revision C and earlier boards:
     Jumper J22 1-2
     Jumper J25 1-2
   Revision D and newer boards:
     DIP switch SW16 positions 3 and 4 set to 1
3. Insert SD card and turn board on
