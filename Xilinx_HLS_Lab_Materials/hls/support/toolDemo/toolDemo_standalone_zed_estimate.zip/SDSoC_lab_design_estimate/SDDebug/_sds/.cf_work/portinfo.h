#ifndef _SDS_PORTINFO_H
#define _SDS_PORTINFO_H
/* File: /proj/xsjhdstaff4/xd-relman/work/Rodin/REL/2015.4_sdsoc/regression/products/sdsoc/platforms/prebuilt/generate/zed/TEST_WORK_lnx64/add_gen_prebuilt/apf/_sds/p0/.cf_work/portinfo.h */
#ifdef __cplusplus
extern "C" {
#endif

void _p0_cf_framework_open(int);
void _p0_cf_framework_close(int);

#ifdef __cplusplus
};
#endif
#ifdef __cplusplus
extern "C" {
#endif
void switch_to_next_partition(int);
void init_first_partition();
void close_last_partition();
#ifdef __cplusplus
};
#endif /* extern "C" */
#endif /* _SDS_PORTINFO_H_ */

// XSIP watermark, do not delete 67d7842dbbe25473c3c32b93c0da8047785f30d78e8a024de1b57352245f9689
