#include <stdlib.h>
#include <sds_incl.h>
#include "cf_stub.h"

cf_request_handle_t _p0_request_0;
cf_request_handle_t _p0_request_1;

size_t _p0_rgb_2_gray_0_num_gray;

